Berikut adalah kode `main.py` lengkap yang menyertakan popup "Selamat Datang" saat aplikasi pertama kali dibuka (setelah menangani proses update jika diperlukan).

```python
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import vlc
import platform
import requests # Tambahkan modul requests
import zipfile  # Tambahkan modul zipfile
import tempfile # Tambahkan modul tempfile
import subprocess # Tambahkan modul subprocess untuk restart
import sys # Tambahkan modul sys untuk restart

# --- Konfigurasi Update ---
APP_VERSION = "1.0.0" # Ganti dengan versi aplikasi Anda saat ini
# Contoh: UPDATE_URL_BASE = "https://yourusername.github.io/your-repo-name/"
UPDATE_URL_BASE = "https://sweeperrlosers21.github.io/anime-player-updates/" # Ganti dengan URL GitHub Pages Anda
VERSION_FILE = "version.txt"
UPDATE_ZIP_FILE = "app_update.zip"
# ----------------------------

class AnimePlayer:
    def __init__(self, root):
        self.root = root
        self.root.title("Anime Player")
        self.root.geometry("1200x700")
        self.root.configure(bg="#1e293b") # slate-800
        
        self.current_folder = ""
        self.anime_files = []
        self.video_extensions = ('.mp4', '.mkv', '.avi', '.mov', '.flv', '.wmv', '.m4v')
        
        # VLC player variables with options to fix hardware acceleration issues
        vlc_args = [
            '--quiet',
            '--no-video-title-show',
            '--avcodec-hw=none',
            '--no-snapshot-preview',
            '--no-stats',
        ]
        try:
            self.instance = vlc.Instance(vlc_args)
        except:
            # Fallback tanpa args jika error
            self.instance = vlc.Instance()
        
        self.player = self.instance.media_player_new()
        self.is_playing = False
        self.current_video = None
        self.is_dragging = False
        self.is_fullscreen = False
        self.previous_geometry = None
        self.fullscreen_controls_visible = False
        self.hide_controls_timer = None
        self.fullscreen_control_frame = None
        
        # Panggil fungsi cek update di awal
        self.check_for_updates()

    def check_for_updates(self):
        """Fungsi untuk mengecek update saat aplikasi dimulai."""
        try:
            response = requests.get(f"{UPDATE_URL_BASE}{VERSION_FILE}", timeout=10)
            response.raise_for_status() # Akan raise exception jika status bukan 200
            latest_version = response.text.strip()
            
            if self.compare_versions(latest_version, APP_VERSION) > 0:
                # Versi server lebih tinggi
                print(f"Update tersedia: {latest_version} > {APP_VERSION}")
                # Tampilkan pop-up konfirmasi
                self.show_update_popup(latest_version)
            else:
                print(f"Aplikasi sudah versi terbaru: {APP_VERSION}")
                # Jika tidak ada update, tampilkan welcome dan lanjutkan ke setup UI
                self.show_welcome_popup()
                self.setup_ui()
        except requests.exceptions.RequestException as e:
            print(f"Gagal mengecek update: {e}")
            # Opsional: Tampilkan peringatan ke pengguna
            messagebox.showwarning("Gagal Mengecek Update", f"Tidak dapat menghubungi server update: {e}")
            # Jika gagal cek update, tetap tampilkan welcome dan lanjutkan ke setup UI
            self.show_welcome_popup()
            self.setup_ui()
        except Exception as e:
            print(f"Error saat mengecek update: {e}")
            messagebox.showerror("Error", f"Terjadi kesalahan saat mengecek update: {e}")
            # Jika error saat cek update, tetap tampilkan welcome dan lanjutkan ke setup UI
            self.show_welcome_popup()
            self.setup_ui()

    def show_update_popup(self, latest_version):
        """Menampilkan pop-up konfirmasi update."""
        # Buat window pop-up
        popup = tk.Toplevel(self.root)
        popup.title("Update Tersedia")
        popup.geometry("400x150")
        popup.configure(bg="#1e293b")
        popup.transient(self.root) # Jadikan window ini anak dari window utama
        popup.grab_set() # Fokus hanya ke window ini

        # Label pesan
        msg_label = tk.Label(
            popup,
            text=f"Versi baru ({latest_version}) tersedia.\nApakah Anda ingin mengunduh dan menginstalnya sekarang?",
            font=("Segoe UI", 10),
            bg="#1e293b",
            fg="#e2e8f0",
            wraplength=350
        )
        msg_label.pack(pady=20)

        # Frame untuk tombol
        button_frame = tk.Frame(popup, bg="#1e293b")
        button_frame.pack()

        # Tombol Update
        update_btn = tk.Button(
            button_frame,
            text="Update",
            font=("Segoe UI", 10, "bold"),
            bg="#e11d48", # rose-600
            fg="white",
            activebackground="#be123c", # rose-700
            cursor="hand2",
            relief=tk.FLAT,
            width=10,
            command=lambda: self.handle_update_choice(popup, latest_version)
        )
        update_btn.pack(side=tk.LEFT, padx=10)

        # Tombol Cancel
        cancel_btn = tk.Button(
            button_frame,
            text="Cancel",
            font=("Segoe UI", 10, "bold"),
            bg="#64748b", # slate-500
            fg="white",
            activebackground="#475569", # slate-600
            cursor="hand2",
            relief=tk.FLAT,
            width=10,
            command=lambda: self.handle_cancel_choice(popup)
        )
        cancel_btn.pack(side=tk.LEFT, padx=10)

        # Tengahkan pop-up
        popup.update_idletasks()
        x = (popup.winfo_screenwidth() // 2) - (popup.winfo_width() // 2)
        y = (popup.winfo_screenheight() // 2) - (popup.winfo_height() // 2)
        popup.geometry(f"+{x}+{y}")

    def handle_update_choice(self, popup, latest_version):
        """Menangani pilihan 'Update' dari pop-up."""
        popup.destroy() # Tutup pop-up
        self.download_and_install_update(latest_version)

    def handle_cancel_choice(self, popup):
        """Menangani pilihan 'Cancel' dari pop-up."""
        popup.destroy() # Tutup pop-up
        # Tampilkan welcome dan lanjutkan ke setup UI jika update dibatalkan
        self.show_welcome_popup()
        self.setup_ui()

    def show_welcome_popup(self):
        """Menampilkan pop-up selamat datang."""
        # Buat window pop-up
        welcome_popup = tk.Toplevel(self.root)
        welcome_popup.title("Selamat Datang")
        welcome_popup.geometry("350x120")
        welcome_popup.configure(bg="#1e293b")
        welcome_popup.transient(self.root) # Jadikan window ini anak dari window utama
        welcome_popup.grab_set() # Fokus hanya ke window ini

        # Label pesan
        msg_label = tk.Label(
            welcome_popup,
            text="Selamat Datang di Anime Player!",
            font=("Segoe UI", 12, "bold"),
            bg="#1e293b",
            fg="#e2e8f0"
        )
        msg_label.pack(pady=20)

        # Tombol Close
        close_btn = tk.Button(
            welcome_popup,
            text="Close",
            font=("Segoe UI", 10, "bold"),
            bg="#64748b", # slate-500
            fg="white",
            activebackground="#475569", # slate-600
            cursor="hand2",
            relief=tk.FLAT,
            width=10,
            command=welcome_popup.destroy # Tutup pop-up
        )
        close_btn.pack()

        # Tengahkan pop-up
        welcome_popup.update_idletasks()
        x = (welcome_popup.winfo_screenwidth() // 2) - (welcome_popup.winfo_width() // 2)
        y = (welcome_popup.winfo_screenheight() // 2) - (welcome_popup.winfo_height() // 2)
        welcome_popup.geometry(f"+{x}+{y}")

    def compare_versions(self, v1, v2):
        """Membandingkan dua string versi (misalnya '1.2.3' vs '1.2.4')."""
        def normalize(v):
            return [int(x) for x in v.split(".")]
        n_v1 = normalize(v1)
        n_v2 = normalize(v2)
        
        # Bandingkan komponen versi satu per satu
        for i in range(max(len(n_v1), len(n_v2))):
            part_v1 = n_v1[i] if i < len(n_v1) else 0
            part_v2 = n_v2[i] if i < len(n_v2) else 0
            if part_v1 > part_v2:
                return 1  # v1 lebih besar
            elif part_v1 < part_v2:
                return -1 # v2 lebih besar
        return 0  # versi sama

    def download_and_install_update(self, latest_version):
        """Fungsi untuk mengunduh dan menginstal update."""
        try:
            zip_url = f"{UPDATE_URL_BASE}{UPDATE_ZIP_FILE}"
            print(f"Mengunduh update dari {zip_url}...")
            
            response = requests.get(zip_url, stream=True, timeout=30)
            response.raise_for_status()

            # Buat file sementara untuk menyimpan zip
            with tempfile.NamedTemporaryFile(delete=False, suffix='.zip') as tmp_zip:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk: # filter out keep-alive chunks
                        tmp_zip.write(chunk)
                temp_zip_path = tmp_zip.name

            print("Download selesai. Mengekstrak...")
            # Ekstrak ke folder sementara
            with tempfile.TemporaryDirectory() as tmp_dir:
                with zipfile.ZipFile(temp_zip_path, 'r') as zip_ref:
                    zip_ref.extractall(tmp_dir)

                # Tentukan file-file yang akan diupdate
                # Anda perlu menyesuaikan ini dengan struktur aplikasi Anda
                # Misalnya, hanya update main.py dan modul-modul tertentu
                update_files = [f for f in os.listdir(tmp_dir) if f.endswith(('.py', '.txt'))] # Contoh filter

                print(f"Memperbarui file: {update_files}")
                for file_name in update_files:
                    src_path = os.path.join(tmp_dir, file_name)
                    dst_path = os.path.join(os.getcwd(), file_name) # Ganti os.getcwd() jika file disimpan di subfolder
                    if os.path.exists(src_path):
                        # Hapus file lama jika ada
                        if os.path.exists(dst_path):
                            os.remove(dst_path)
                        # Pindahkan file baru
                        import shutil
                        shutil.move(src_path, dst_path)
                        print(f"Terupdate: {file_name}")

            # Hapus file zip sementara
            os.remove(temp_zip_path)
            print("Update berhasil diinstal.")
            
            # Restart aplikasi
            messagebox.showinfo("Update Berhasil", f"Versi {latest_version} telah diinstal. Aplikasi akan dinyalakan ulang.")
            self.restart_application()

        except requests.exceptions.RequestException as e:
            print(f"Gagal mengunduh update: {e}")
            messagebox.showerror("Gagal Mengunduh", f"Tidak dapat mengunduh file update: {e}")
        except zipfile.BadZipFile:
            print("File ZIP tidak valid.")
            messagebox.showerror("Gagal", "File update yang diunduh rusak.")
        except Exception as e:
            print(f"Error saat menginstal update: {e}")
            messagebox.showerror("Gagal", f"Terjadi kesalahan saat menginstal update: {e}")

    def restart_application(self):
        """Fungsi untuk merestart aplikasi."""
        print("Merestart aplikasi...")
        # Hentikan player dulu
        self.player.stop()
        # Matikan GUI
        self.root.destroy()
        # Restart proses Python
        subprocess.Popen([sys.executable] + sys.argv)
        # Keluarkan proses lama
        sys.exit()

    def setup_ui(self):
        # Main Container (tidak ada header_frame lagi)
        main_frame = tk.Frame(self.root, bg="#1e293b") # slate-800
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10) # Menambahkan pady untuk margin atas/bawah
        
        # Left Panel - Video Player
        left_frame = tk.Frame(main_frame, bg="#0f172a") # slate-900
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        # Video Display Frame
        video_frame = tk.Frame(left_frame, bg="#0f172a") # slate-900
        video_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create a frame for VLC player
        self.video_panel = tk.Frame(video_frame, bg="#0f172a") # slate-900
        self.video_panel.pack(fill=tk.BOTH, expand=True)
        
        # Video Title
        self.video_title = tk.Label(
            left_frame,
            text="No video loaded",
            font=("Segoe UI", 11, "bold"),
            bg="#0f172a",
            fg="#cbd5e1", # slate-300
            wraplength=600
        )
        self.video_title.pack(pady=5)
        
        # Progress Bar
        progress_frame = tk.Frame(left_frame, bg="#0f172a")
        progress_frame.pack(fill=tk.X, padx=15, pady=5)
        
        self.time_label = tk.Label(
            progress_frame,
            text="00:00",
            font=("Segoe UI", 9),
            bg="#0f172a",
            fg="#94a3b8" # slate-400
        )
        self.time_label.pack(side=tk.LEFT, padx=5)
        
        # Gaya progress bar modern
        style = ttk.Style()
        style.configure("Custom.Horizontal.TProgressbar", 
                        troughcolor="#334155", # slate-700
                        background="#e11d48", # rose-600
                        thickness=6)
        
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Scale(
            progress_frame,
            from_=0,
            to=100,
            orient=tk.HORIZONTAL,
            variable=self.progress_var,
            command=self.on_progress_drag,
            length=400
        )
        self.progress_bar.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.progress_bar.bind("<ButtonPress-1>", self.on_progress_press)
        self.progress_bar.bind("<ButtonRelease-1>", self.on_progress_release)
        
        self.duration_label = tk.Label(
            progress_frame,
            text="00:00",
            font=("Segoe UI", 9),
            bg="#0f172a",
            fg="#94a3b8" # slate-400
        )
        self.duration_label.pack(side=tk.LEFT, padx=5)
        
        # Control Panel
        control_frame = tk.Frame(left_frame, bg="#0f172a")
        control_frame.pack(fill=tk.X, padx=15, pady=10)
        
        # Play/Pause Button
        self.play_pause_btn = tk.Button(
            control_frame,
            text="Play",
            font=("Segoe UI", 10, "bold"),
            bg="#e11d48", # rose-600
            fg="white",
            activebackground="#be123c", # rose-700
            cursor="hand2",
            relief=tk.FLAT,
            width=8,
            command=self.toggle_play_pause
        )
        self.play_pause_btn.pack(side=tk.LEFT, padx=5)
        
        # Stop Button
        self.stop_btn = tk.Button(
            control_frame,
            text="Stop",
            font=("Segoe UI", 10, "bold"),
            bg="#64748b", # slate-500
            fg="white",
            activebackground="#475569", # slate-600
            cursor="hand2",
            relief=tk.FLAT,
            width=8,
            command=self.stop_video
        )
        self.stop_btn.pack(side=tk.LEFT, padx=5)
        
        # Fullscreen Button
        self.fullscreen_btn = tk.Button(
            control_frame,
            text="Fullscreen",
            font=("Segoe UI", 10, "bold"),
            bg="#64748b", # slate-500
            fg="white",
            activebackground="#475569", # slate-600
            cursor="hand2",
            relief=tk.FLAT,
            width=10,
            command=self.toggle_fullscreen
        )
        self.fullscreen_btn.pack(side=tk.LEFT, padx=5)
        
        # Speed Control
        speed_frame = tk.Frame(control_frame, bg="#0f172a")
        speed_frame.pack(side=tk.LEFT, padx=15)
        
        tk.Label(
            speed_frame,
            text="Speed:",
            font=("Segoe UI", 9),
            bg="#0f172a",
            fg="#e2e8f0" # slate-200
        ).pack(side=tk.LEFT, padx=3)
        
        self.speed_var = tk.StringVar(value="1.0x")
        speed_combo = ttk.Combobox(
            speed_frame,
            textvariable=self.speed_var,
            values=["0.25x", "0.5x", "0.75x", "1.0x", "1.25x", "1.5x", "1.75x", "2.0x"],
            width=6,
            state="readonly",
            style="Custom.TCombobox"
        )
        speed_combo.pack(side=tk.LEFT)
        speed_combo.bind("<<ComboboxSelected>>", self.change_speed)
        
        # Volume Control
        volume_frame = tk.Frame(control_frame, bg="#0f172a")
        volume_frame.pack(side=tk.RIGHT, padx=5)
        
        self.volume_icon = tk.Label(
            volume_frame,
            text="🔊",
            font=("Segoe UI", 10, "bold"),
            bg="#0f172a",
            fg="#e2e8f0", # slate-200
            cursor="hand2"
        )
        self.volume_icon.pack(side=tk.LEFT, padx=5)
        self.volume_icon.bind("<Button-1>", self.toggle_mute)
        
        self.volume_var = tk.IntVar(value=70)
        self.volume_scale = ttk.Scale(
            volume_frame,
            from_=0,
            to=100,
            orient=tk.HORIZONTAL,
            variable=self.volume_var,
            command=self.change_volume,
            length=150
        )
        self.volume_scale.pack(side=tk.LEFT)
        
        self.volume_label = tk.Label(
            volume_frame,
            text="70%",
            font=("Segoe UI", 9),
            bg="#0f172a",
            fg="#e2e8f0", # slate-200
            width=4
        )
        self.volume_label.pack(side=tk.LEFT, padx=5)
        
        # Set initial volume
        self.player.audio_set_volume(70)
        
        # Right Panel - Folder Selection & Anime List
        right_frame = tk.Frame(main_frame, bg="#0f172a", width=350)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH)
        right_frame.pack_propagate(False)
        
        # Folder Selection
        tk.Label(
            right_frame,
            text="Select Anime Folder",
            font=("Segoe UI", 12, "bold"),
            bg="#0f172a",
            fg="#e2e8f0" # slate-200
        ).pack(pady=10)
        
        self.folder_button = tk.Button(
            right_frame,
            text="📁 Browse Folder",
            font=("Segoe UI", 10),
            bg="#e11d48", # rose-600
            fg="white",
            activebackground="#be123c", # rose-700
            activeforeground="white",
            cursor="hand2",
            relief=tk.FLAT,
            padx=15,
            pady=8,
            command=self.browse_folder
        )
        self.folder_button.pack(pady=5, padx=15, fill=tk.X)
        
        # Current Folder Display
        self.folder_label = tk.Label(
            right_frame,
            text="Not selected",
            font=("Segoe UI", 8),
            bg="#0f172a",
            fg="#94a3b8", # slate-400
            wraplength=320,
            justify=tk.LEFT
        )
        self.folder_label.pack(pady=5, padx=10)
        
        # File Count
        self.count_label = tk.Label(
            right_frame,
            text="Total: 0 files",
            font=("Segoe UI", 9, "bold"),
            bg="#0f172a",
            fg="#e11d48" # rose-600
        )
        self.count_label.pack(pady=5)
        
        # Search Box
        search_frame = tk.Frame(right_frame, bg="#0f172a")
        search_frame.pack(fill=tk.X, padx=15, pady=10)
        
        tk.Label(
            search_frame,
            text="🔍",
            font=("Segoe UI", 11),
            bg="#0f172a",
            fg="#e2e8f0" # slate-200
        ).pack(side=tk.LEFT, padx=(0, 5))
        
        self.search_var = tk.StringVar()
        self.search_var.trace('w', self.filter_anime)
        
        self.search_entry = tk.Entry(
            search_frame,
            textvariable=self.search_var,
            font=("Segoe UI", 10),
            bg="#334155", # slate-700
            fg="#f8fafc", # slate-50
            insertbackground="#f8fafc",
            relief=tk.FLAT,
            highlightthickness=1,
            highlightcolor="#e11d48" # rose-600
        )
        self.search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=4)
        
        tk.Label(
            right_frame,
            text="Anime List",
            font=("Segoe UI", 11, "bold"),
            bg="#0f172a",
            fg="#e2e8f0" # slate-200
        ).pack(pady=5)
        
        # Listbox Frame with Scrollbar
        list_frame = tk.Frame(right_frame, bg="#0f172a")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 10))
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.anime_listbox = tk.Listbox(
            list_frame,
            font=("Segoe UI", 10),
            bg="#334155", # slate-700
            fg="#e2e8f0", # slate-200
            selectbackground="#e11d48", # rose-600
            selectforeground="white",
            activestyle="none",
            relief=tk.FLAT,
            yscrollcommand=scrollbar.set,
            highlightthickness=0,
            borderwidth=0
        )
        self.anime_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.anime_listbox.yview)
        
        # Bind double-click to play
        self.anime_listbox.bind('<Double-Button-1>', self.play_selected)
        
        # Bind ESC key to exit fullscreen
        self.root.bind('<Escape>', self.exit_fullscreen)
        # Bind F key to toggle fullscreen
        self.root.bind('<f>', self.toggle_fullscreen)
        self.root.bind('<F>', self.toggle_fullscreen)
        
        # Bind VLC to video panel
        self.root.update()
        if platform.system() == "Windows":
            self.player.set_hwnd(self.video_panel.winfo_id())
        elif platform.system() == "Darwin":  # macOS
            self.player.set_nsobject(self.video_panel.winfo_id())
        else:  # Linux
            self.player.set_xwindow(self.video_panel.winfo_id())
    
    def browse_folder(self):
        folder = filedialog.askdirectory(title="Select Anime Folder")
        if folder:
            self.current_folder = folder
            self.folder_label.config(text=folder)
            self.load_anime_files()
            
    def load_anime_files(self):
        self.anime_files = []
        self.anime_listbox.delete(0, tk.END)
        
        try:
            for file in os.listdir(self.current_folder):
                if file.lower().endswith(self.video_extensions):
                    self.anime_files.append(file)
            
            self.anime_files.sort()
            
            for file in self.anime_files:
                self.anime_listbox.insert(tk.END, file)
            
            self.count_label.config(text=f"Total: {len(self.anime_files)} files")
            
            if not self.anime_files:
                messagebox.showinfo("Info", "No video files found in this folder.")
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read folder: {str(e)}")
            
    def filter_anime(self, *args):
        search_term = self.search_var.get().lower()
        self.anime_listbox.delete(0, tk.END)
        
        for file in self.anime_files:
            if search_term in file.lower():
                self.anime_listbox.insert(tk.END, file)
                
    def play_selected(self, event=None):
        selection = self.anime_listbox.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Please select an anime to play!")
            return
        
        selected_file = self.anime_listbox.get(selection[0])
        file_path = os.path.join(self.current_folder, selected_file)
        
        self.load_video(file_path, selected_file)
        
    def load_video(self, video_path, video_name):
        try:
            # Load media
            media = self.instance.media_new(video_path)
            self.player.set_media(media)
            
            # Update UI
            self.current_video = video_path
            self.video_title.config(text=video_name)
            
            # Play video
            self.player.play()
            self.is_playing = True
            self.play_pause_btn.config(text="Pause")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load video: {str(e)}")
            
    def toggle_play_pause(self):
        if self.player.get_media() is None:
            if not self.is_fullscreen:
                messagebox.showwarning("Warning", "Please select a video first!")
            return
        
        if self.is_playing:
            self.player.pause()
            self.is_playing = False
            self.play_pause_btn.config(text="Play")
            if self.is_fullscreen and hasattr(self, 'fs_play_pause_btn'):
                self.fs_play_pause_btn.config(text="Play")
        else:
            self.player.play()
            self.is_playing = True
            self.play_pause_btn.config(text="Pause")
            if self.is_fullscreen and hasattr(self, 'fs_play_pause_btn'):
                self.fs_play_pause_btn.config(text="Pause")
                
    def stop_video(self):
        self.player.stop()
        self.is_playing = False
        self.play_pause_btn.config(text="Play")
        self.progress_var.set(0)
        self.time_label.config(text="00:00")
        self.duration_label.config(text="00:00")
        
    def change_volume(self, value):
        volume = int(float(value))
        self.player.audio_set_volume(volume)
        self.volume_label.config(text=f"{volume}%")
        
        # Sync with fullscreen volume if exists
        if hasattr(self, 'fs_volume_var'):
            self.fs_volume_var.set(volume)
        if hasattr(self, 'fs_volume_label'):
            self.fs_volume_label.config(text=f"{volume}%")
        
        # Update volume icon text
        icon_text = "🔇" if volume == 0 else "🔊"
        self.volume_icon.config(text=icon_text)
        if hasattr(self, 'fs_volume_icon'):
            self.fs_volume_icon.config(text=icon_text)
    
    def toggle_mute(self, event=None):
        is_muted = self.player.audio_get_mute()
        self.player.audio_set_mute(not is_muted)
        
        icon_text = "🔊" if not is_muted else "🔇"
        
        if hasattr(self, 'volume_icon'):
            self.volume_icon.config(text=icon_text)
        if hasattr(self, 'fs_volume_icon'):
            self.fs_volume_icon.config(text=icon_text)
    
    def change_speed(self, event=None):
        speed_text = self.speed_var.get()
        speed = float(speed_text.replace('x', ''))
        self.player.set_rate(speed)
    
    def toggle_fullscreen(self, event=None):
        if self.is_fullscreen:
            self.exit_fullscreen()
        else:
            self.enter_fullscreen()
    
    def enter_fullscreen(self):
        # Simpan geometry saat ini
        self.previous_geometry = self.root.geometry()
        
        # Sembunyikan semua UI kecuali video panel
        for widget in self.root.winfo_children():
            if widget != self.root.winfo_children()[0]:  # Keep only main_frame (index 0 now)
                widget.pack_forget()
        
        # Get main_frame (index 0 now)
        main_frame = self.root.winfo_children()[0]
        
        # Hide right panel and show only video
        for child in main_frame.winfo_children():
            child.pack_forget()
        
        # Repack only the left frame (video player) to fill entire screen
        left_frame = main_frame.winfo_children()[0]
        left_frame.pack(fill=tk.BOTH, expand=True)
        
        # Hide all controls in left frame except video
        for widget in left_frame.winfo_children():
            widget.pack_forget()
        
        # Show only video panel
        video_frame = left_frame.winfo_children()[0]
        video_frame.pack(fill=tk.BOTH, expand=True, padx=0, pady=0)
        
        # Create ESC hint at top
        self.create_esc_hint(left_frame)
        
        # Create fullscreen controls overlay
        self.create_fullscreen_controls(left_frame)
        
        # Fullscreen mode
        self.root.attributes('-fullscreen', True)
        self.is_fullscreen = True
        self.fullscreen_btn.config(text="Exit Full")
        
        # Bind mouse motion to show controls
        self.root.bind('<Motion>', self.on_mouse_move_fullscreen)
    
    def create_esc_hint(self, parent):
        # Create hint frame at top
        self.esc_hint_frame = tk.Frame(parent, bg="#000000", height=50)
        self.esc_hint_frame.place(relx=0.5, rely=0, anchor='n')
        
        # Inner container
        hint_inner = tk.Frame(self.esc_hint_frame, bg="#1a1a1a")
        hint_inner.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        hint_label = tk.Label(
            hint_inner,
            text="Press ESC to exit fullscreen",
            font=("Segoe UI", 11),
            bg="#1a1a1a",
            fg="#eee"
        )
        hint_label.pack(pady=8)
        
        # Auto hide after 5 seconds
        self.root.after(5000, self.hide_esc_hint)
    
    def hide_esc_hint(self):
        if hasattr(self, 'esc_hint_frame') and self.esc_hint_frame:
            self.esc_hint_frame.place_forget()
        
    def create_fullscreen_controls(self, parent):
        # Create overlay frame at bottom
        self.fullscreen_control_frame = tk.Frame(parent, bg="#000000", height=150)
        self.fullscreen_control_frame.place(relx=0, rely=1, relwidth=1, anchor='sw')
        self.fullscreen_control_frame.place_forget()  # Hide initially
        
        # Inner container with semi-transparent background
        inner_frame = tk.Frame(self.fullscreen_control_frame, bg="#1a1a1a")
        inner_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # Time and progress bar
        time_frame = tk.Frame(inner_frame, bg="#1a1a1a")
        time_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.fs_time_label = tk.Label(
            time_frame,
            text="00:00",
            font=("Segoe UI", 12),
            bg="#1a1a1a",
            fg="#eee"
        )
        self.fs_time_label.pack(side=tk.LEFT, padx=10)
        
        self.fs_progress_var = tk.DoubleVar()
        self.fs_progress_bar = ttk.Scale(
            time_frame,
            from_=0,
            to=100,
            orient=tk.HORIZONTAL,
            variable=self.fs_progress_var,
            command=self.on_fs_progress_drag
        )
        self.fs_progress_bar.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.fs_progress_bar.bind("<ButtonPress-1>", self.on_progress_press)
        self.fs_progress_bar.bind("<ButtonRelease-1>", self.on_progress_release)
        
        self.fs_duration_label = tk.Label(
            time_frame,
            text="00:00",
            font=("Segoe UI", 12),
            bg="#1a1a1a",
            fg="#eee"
        )
        self.fs_duration_label.pack(side=tk.LEFT, padx=10)
        
        # Control buttons
        control_frame = tk.Frame(inner_frame, bg="#1a1a1a")
        control_frame.pack()
        
        # Backward 10s button
        self.fs_backward_btn = tk.Button(
            control_frame,
            text="⏪ -10s",
            font=("Segoe UI", 14, "bold"),
            bg="#e11d48", # rose-600
            fg="white",
            activebackground="#be123c", # rose-700
            cursor="hand2",
            relief=tk.FLAT,
            width=10,
            command=self.backward_10s
        )
        self.fs_backward_btn.pack(side=tk.LEFT, padx=10)
        
        # Play/Pause button
        self.fs_play_pause_btn = tk.Button(
            control_frame,
            text="Pause" if self.is_playing else "Play",
            font=("Segoe UI", 14, "bold"),
            bg="#e11d48", # rose-600
            fg="white",
            activebackground="#be123c", # rose-700
            cursor="hand2",
            relief=tk.FLAT,
            width=10,
            command=self.toggle_play_pause
        )
        self.fs_play_pause_btn.pack(side=tk.LEFT, padx=10)
        
        # Forward 10s button
        self.fs_forward_btn = tk.Button(
            control_frame,
            text="+10s ⏩",
            font=("Segoe UI", 14, "bold"),
            bg="#e11d48", # rose-600
            fg="white",
            activebackground="#be123c", # rose-700
            cursor="hand2",
            relief=tk.FLAT,
            width=10,
            command=self.forward_10s
        )
        self.fs_forward_btn.pack(side=tk.LEFT, padx=10)
        
        # Volume control in fullscreen
        volume_frame = tk.Frame(inner_frame, bg="#1a1a1a")
        volume_frame.pack(pady=(10, 0))
        
        self.fs_volume_icon = tk.Label(
            volume_frame,
            text="🔊",
            font=("Segoe UI", 11, "bold"),
            bg="#1a1a1a",
            fg="#eee",
            cursor="hand2"
        )
        self.fs_volume_icon.pack(side=tk.LEFT, padx=5)
        self.fs_volume_icon.bind("<Button-1>", self.toggle_mute)
        
        self.fs_volume_var = tk.IntVar(value=self.volume_var.get())
        self.fs_volume_scale = ttk.Scale(
            volume_frame,
            from_=0,
            to=100,
            orient=tk.HORIZONTAL,
            variable=self.fs_volume_var,
            command=self.change_volume_fs,
            length=200
        )
        self.fs_volume_scale.pack(side=tk.LEFT, padx=5)
        
        self.fs_volume_label = tk.Label(
            volume_frame,
            text=f"{self.volume_var.get()}%",
            font=("Segoe UI", 10),
            bg="#1a1a1a",
            fg="#eee",
            width=4
        )
        self.fs_volume_label.pack(side=tk.LEFT, padx=5)
    
    def change_volume_fs(self, value):
        # Update both volume controls
        volume = int(float(value))
        self.volume_var.set(volume)
        self.player.audio_set_volume(volume)
        
        # Update labels
        if hasattr(self, 'volume_label'):
            self.volume_label.config(text=f"{volume}%")
        if hasattr(self, 'fs_volume_label'):
            self.fs_volume_label.config(text=f"{volume}%")
        
        # Update icons
        icon_text = "🔇" if volume == 0 else "🔊"
        if hasattr(self, 'volume_icon'):
            self.volume_icon.config(text=icon_text)
        if hasattr(self, 'fs_volume_icon'):
            self.fs_volume_icon.config(text=icon_text)
    
    def on_mouse_move_fullscreen(self, event):
        if self.is_fullscreen:
            # Show ESC hint if near top
            if event.y < 100 and hasattr(self, 'esc_hint_frame'):
                self.esc_hint_frame.place(relx=0.5, rely=0, anchor='n')
            
            # Show controls if near bottom or controls frame
            if self.fullscreen_control_frame:
                self.fullscreen_control_frame.place(relx=0, rely=1, relwidth=1, anchor='sw')
                self.fullscreen_controls_visible = True
                
                # Cancel previous hide timer
                if self.hide_controls_timer:
                    self.root.after_cancel(self.hide_controls_timer)
                
                # Set timer to hide controls after 3 seconds of no movement
                self.hide_controls_timer = self.root.after(3000, self.hide_fullscreen_controls)
    
    def hide_fullscreen_controls(self):
        if self.fullscreen_control_frame and self.is_fullscreen:
            self.fullscreen_control_frame.place_forget()
            self.fullscreen_controls_visible = False
        
        # Also hide ESC hint
        if hasattr(self, 'esc_hint_frame') and self.esc_hint_frame:
            self.esc_hint_frame.place_forget()
    
    def on_fs_progress_drag(self, value):
        if self.is_dragging:
            current_time = (float(value) / 100) * (self.player.get_length() / 1000)
            self.fs_time_label.config(text=self.format_time(current_time))
    
    def on_fs_progress_release(self, event=None):
        self.is_dragging = False
        self.seek_video(self.fs_progress_var.get())
    
    def backward_10s(self):
        if self.player.get_media() is not None:
            current_time = self.player.get_time()
            new_time = max(0, current_time - 10000)  # 10 seconds in milliseconds
            self.player.set_time(int(new_time))
    
    def forward_10s(self):
        if self.player.get_media() is not None:
            current_time = self.player.get_time()
            video_length = self.player.get_length()
            new_time = min(video_length, current_time + 10000)  # 10 seconds in milliseconds
            self.player.set_time(int(new_time))
    
    def exit_fullscreen(self, event=None):
        if self.is_fullscreen:
            # Unbind mouse motion
            self.root.unbind('<Motion>')
            
            # Cancel hide timer
            if self.hide_controls_timer:
                self.root.after_cancel(self.hide_controls_timer)
            
            # Destroy ESC hint
            if hasattr(self, 'esc_hint_frame') and self.esc_hint_frame:
                self.esc_hint_frame.destroy()
                self.esc_hint_frame = None
            
            # Destroy fullscreen controls
            if self.fullscreen_control_frame:
                self.fullscreen_control_frame.destroy()
                self.fullscreen_control_frame = None
            
            self.root.attributes('-fullscreen', False)
            self.is_fullscreen = False
            
            # Restore geometry
            if self.previous_geometry:
                self.root.geometry(self.previous_geometry)
            
            # Re-setup UI
            self.root.after(10, self.restore_ui)
    
    def restore_ui(self):
        # Save current state
        current_folder = self.current_folder
        anime_files = self.anime_files.copy()
        current_video_path = self.current_video
        was_playing = self.is_playing
        current_position = self.player.get_position() if self.player else 0
        
        # Clear all
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Rebuild UI
        self.setup_ui()
        
        # Restore folder and anime list
        if current_folder:
            self.current_folder = current_folder
            self.folder_label.config(text=current_folder)
            self.anime_files = anime_files
            
            # Restore list
            self.anime_listbox.delete(0, tk.END)
            for file in self.anime_files:
                self.anime_listbox.insert(tk.END, file)
            
            self.count_label.config(text=f"Total: {len(self.anime_files)} files")
        
        # Rebind player to new panel and reload video
        self.root.update()
        if platform.system() == "Windows":
            self.player.set_hwnd(self.video_panel.winfo_id())
        elif platform.system() == "Darwin":
            self.player.set_nsobject(self.video_panel.winfo_id())
        else:
            self.player.set_xwindow(self.video_panel.winfo_id())
        
        # Restore video if playing
        if current_video_path:
            video_name = os.path.basename(current_video_path)
            self.current_video = current_video_path
            self.video_title.config(text=video_name)
            
            # Reload media to fix black screen
            media = self.instance.media_new(current_video_path)
            self.player.set_media(media)
            
            # Wait a bit for media to load
            self.root.after(100, lambda: self.restore_playback(current_position, was_playing))
    
    def restore_playback(self, position, was_playing):
        # Start playing to load frames
        self.player.play()
        
        # Set position after a short delay
        if position > 0:
            self.root.after(200, lambda: self.player.set_position(position))
        
        # Update UI based on play state
        if was_playing:
            self.play_pause_btn.config(text="Pause")
            self.is_playing = True
        else:
            # Pause after loading if it wasn't playing
            self.root.after(300, lambda: self.pause_after_restore())
    
    def pause_after_restore(self):
        self.player.pause()
        self.play_pause_btn.config(text="Play")
        self.is_playing = False
    
    def on_progress_press(self, event=None):
        self.is_dragging = True
    
    def on_progress_release(self, event=None):
        self.is_dragging = False
        self.seek_video(self.progress_var.get())
    
    def on_progress_drag(self, value):
        if self.is_dragging:
            current_time = (float(value) / 100) * (self.player.get_length() / 1000)
            self.time_label.config(text=self.format_time(current_time))
        
    def seek_video(self, value):
        if self.player.get_media() is not None:
            position = float(value) / 100
            self.player.set_position(position)
            
    def update_timer(self):
        if self.player.get_media() is not None and not self.is_dragging:
            # Update progress
            length = self.player.get_length() / 1000  # Convert to seconds
            current = self.player.get_time() / 1000  # Convert to seconds
            
            if length > 0:
                progress = (current / length) * 100
                self.progress_var.set(progress)
                self.time_label.config(text=self.format_time(current))
                self.duration_label.config(text=self.format_time(length))
                
                # Update fullscreen controls if visible
                if self.is_fullscreen and hasattr(self, 'fs_time_label'):
                    self.fs_progress_var.set(progress)
                    self.fs_time_label.config(text=self.format_time(current))
                    self.fs_duration_label.config(text=self.format_time(length))
        
        # Schedule next update
        self.root.after(100, self.update_timer)
        
    def format_time(self, seconds):
        mins = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{mins:02d}:{secs:02d}"
        
    def on_closing(self):
        self.player.stop()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = AnimePlayer(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()
```